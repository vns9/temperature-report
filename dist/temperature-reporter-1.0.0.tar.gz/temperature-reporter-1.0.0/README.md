# Temperature Reporter

A Python package to get temperature of any location.

## Usage

Following query on terminal will provide you the temperature of "delhi" for next 3 days.

```
temperature-reporter -q delhi -d 3
```